/**
 * ZexCore Enterprise Homepage
 * Matches reference design: Split hero with photo & 4 metric badges,
 * 3-tier isometric stack section, vertical SaaS split photo section, and trust badges bar.
 */

import { renderNavbar } from '../components/navbar';
import { renderFooter } from '../components/footer';

export function renderHomePage(): string {
  return `
    <div class="page-wrapper">
      ${renderNavbar('home')}

      <main>
        <!-- ── HERO SECTION ─────────────────────────────────────────────── -->
        <section class="section-white hero-split-section" style="padding: 60px 0 40px 0;">
          <div class="site-container">
            <div class="hero-split-grid">
              <!-- Left Column: Copy & CTAs -->
              <div class="hero-copy-col">
                <div class="section-eyebrow" style="margin-bottom: 16px;">
                  ENTERPRISE INFRASTRUCTURE PLATFORM
                </div>
                <h1 class="hero-headline" style="font-size: 3.4rem; font-weight: 800; line-height: 1.1; margin-bottom: 20px; letter-spacing: -0.03em;">
                  One Core.<br />
                  <span style="color: var(--primary);">Infinite Possibilities.</span>
                </h1>
                <p class="hero-subtext" style="font-size: 1.05rem; line-height: 1.65; color: var(--text-secondary); margin-bottom: 32px; max-width: 520px;">
                  The sovereign multi-tenant foundation engineered for mission-critical, IoT telemetry, deterministic rules automation, isolated CRM pipelines, and cryptographic compliance vaults.
                </p>
                <div class="hero-actions-row" style="display: flex; gap: 14px; margin-bottom: 48px;">
                  <a href="#/console" class="btn btn-primary btn-lg" id="btn-hero-launch">
                    Launch Console &rarr;
                  </a>
                  <a href="#/architecture" class="btn btn-outline btn-lg" id="btn-hero-arch">
                    Explore the Architecture
                  </a>
                </div>
              </div>

              <!-- Right Column: Authentic Team Photography -->
              <div class="hero-photo-col">
                <div class="hero-photo-frame">
                  <img
                    src="/hero-team.jpg"
                    alt="Enterprise engineering team collaborating on multi-tenant infrastructure"
                    class="hero-photo-img"
                    loading="eager"
                  />
                </div>
              </div>
            </div>

            <!-- 4 Metric Cards Row Under Hero -->
            <div class="hero-metrics-4col">
              <div class="hero-metric-card">
                <div class="metric-icon-wrap">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                  </svg>
                </div>
                <div>
                  <div class="metric-big-val">100% RLS</div>
                  <div class="metric-sub-lbl">Row-Level Security</div>
                </div>
              </div>

              <div class="hero-metric-card">
                <div class="metric-icon-wrap">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2">
                    <polyline points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
                  </svg>
                </div>
                <div>
                  <div class="metric-big-val">&lt; 1ms</div>
                  <div class="metric-sub-lbl">Rules Engine</div>
                </div>
              </div>

              <div class="hero-metric-card">
                <div class="metric-icon-wrap">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                  </svg>
                </div>
                <div>
                  <div class="metric-big-val">AES-256-GCM</div>
                  <div class="metric-sub-lbl">Encryption</div>
                </div>
              </div>

              <div class="hero-metric-card">
                <div class="metric-icon-wrap">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2">
                    <polygon points="12 2 2 7 12 12 22 7 12 2"/>
                    <polyline points="2 17 12 22 22 17"/>
                    <polyline points="2 12 12 17 22 12"/>
                  </svg>
                </div>
                <div>
                  <div class="metric-big-val">5 Modules</div>
                  <div class="metric-sub-lbl">EventBus Mesh</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- ── SECTION 2: ENGINEERED FOR STRICT SOVEREIGN MULTI-TENANCY ── -->
        <section class="section-gray section-padded" style="padding: 80px 0;">
          <div class="site-container">
            <div class="multi-tenant-split-grid">
              <!-- Left Column: Copy & Button -->
              <div class="multi-tenant-copy">
                <div class="section-eyebrow" style="margin-bottom: 12px;">MULTI-TENANT PLATFORM</div>
                <h2 class="section-title" style="text-align: left; font-size: 2.2rem; margin-bottom: 16px;">
                  Engineered for Strict Sovereign Multi-Tenancy
                </h2>
                <p style="font-size: 1rem; color: var(--text-secondary); line-height: 1.7; margin-bottom: 32px; max-width: 480px;">
                  Build for scale, definition and workflow execution &mdash; ZexCore delivers the infrastructure your vertical SaaS needs to grow, securely.
                </p>
                <a href="#/architecture" class="btn btn-primary btn-lg">
                  Learn More About Our Architecture &rarr;
                </a>
              </div>

              <!-- Right Column: Isometric platform stack from the design reference -->
              <div class="stack-illustration-col">
                <div class="platform-stack-diagram" role="img" aria-label="ZexCore platform shown as three stacked isometric layers: Industry Packs, Reusable Modules, and ZexCore Core">
                  <div class="platform-stack-art">
                    <svg class="platform-stack-svg" viewBox="0 0 520 470" aria-hidden="true" focusable="false">
                      <defs>
                        <linearGradient id="stackTop" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#fff4f5"/></linearGradient>
                        <linearGradient id="stackSide" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe7ea"/><stop offset="1" stop-color="#f7cbd0"/></linearGradient>
                        <filter id="stackShadow" x="-30%" y="-30%" width="160%" height="180%"><feDropShadow dx="0" dy="8" stdDeviation="7" flood-color="#9d1b2b" flood-opacity=".12"/></filter>
                      </defs>
                      <g filter="url(#stackShadow)" stroke-linejoin="round">
                        <!-- Top slab: industry configuration packs -->
                        <polygon points="250,70 366,126 250,182 134,126" fill="url(#stackTop)" stroke="#efb2b9" stroke-width="1.7"/>
                        <polygon points="134,126 250,182 250,193 134,137" fill="url(#stackSide)" stroke="#e8a0a9" stroke-width="1.2"/>
                        <polygon points="250,182 366,126 366,137 250,193" fill="#f8d6da" stroke="#e8a0a9" stroke-width="1.2"/>
                        <!-- Middle slab: reusable modules, visibly separated -->
                        <polygon points="250,157 392,226 250,295 108,226" fill="url(#stackTop)" stroke="#e99aa4" stroke-width="1.7"/>
                        <polygon points="108,226 250,295 250,307 108,238" fill="url(#stackSide)" stroke="#e3a0a8" stroke-width="1.2"/>
                        <polygon points="250,295 392,226 392,238 250,307" fill="#f7d2d6" stroke="#e3a0a8" stroke-width="1.2"/>
                        <!-- Base slab: the multi-tenant core -->
                        <polygon points="250,260 432,348 250,436 68,348" fill="url(#stackTop)" stroke="#d71920" stroke-width="2.1"/>
                        <polygon points="68,348 250,436 250,448 68,360" fill="#f4c4ca" stroke="#d71920" stroke-width="1.4"/>
                        <polygon points="250,436 432,348 432,360 250,448" fill="#f8d5d9" stroke="#d71920" stroke-width="1.4"/>
                      </g>
                      <!-- Compact brand mark placed on the top platform surface -->
                      <image href="/zexcore-logo-icon.png" x="215" y="91" width="70" height="70" preserveAspectRatio="xMidYMid meet" />
                    </svg>
                  </div>
                  <div class="platform-stack-labels" aria-hidden="true">
                    <div class="platform-stack-label label-industry"><span class="stack-label-dot"></span><div><strong>Industry Packs</strong><small>Vertical configurations</small></div></div>
                    <div class="platform-stack-label label-modules"><span class="stack-label-dot"></span><div><strong>Reusable Modules</strong><small>Core platform capabilities</small></div></div>
                    <div class="platform-stack-label label-core"><span class="stack-label-dot"></span><div><strong>ZexCore Core</strong><small>Multi-tenant infrastructure</small></div></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- ── SECTION 3: POWERING THE NEXT GENERATION OF VERTICAL SAAS ── -->
        <section class="section-white section-padded" style="padding: 80px 0;">
          <div class="site-container">
            <div class="powering-saas-grid">
              <!-- Left Column: Industrial Plant Photo -->
              <div class="powering-photo-col">
                <div class="powering-photo-frame">
                  <img
                    src="/refinery.jpg"
                    alt="Engineer in hardhat working on vertical SaaS automation in an industrial plant"
                    class="powering-photo-img"
                    loading="lazy"
                  />
                </div>
              </div>

              <!-- Right Column: Copy & Explore Button -->
              <div class="powering-copy-col">
                <h2 class="section-title" style="text-align: left; font-size: 2.2rem; margin-bottom: 20px;">
                  Powering the next generation of vertical SaaS
                </h2>
                <p style="font-size: 1rem; color: var(--text-secondary); line-height: 1.7; margin-bottom: 32px; max-width: 500px;">
                  From industrial IoT to healthcare, ZexCore gives you the foundation to build, scale and operate industry-specific applications with confidence.
                </p>
                <a href="#/solutions" class="btn btn-outline btn-lg">
                  Explore Solutions &rarr;
                </a>
              </div>
            </div>
          </div>
        </section>

        <!-- ── SECTION 4: TRUSTED BY FORWARD-THINKING TEAMS ─────────────── -->
        <section class="section-gray section-padded" style="padding: 48px 0 64px 0; border-top: 1px solid var(--border-default);">
          <div class="site-container">
            <div class="trust-bar-header" style="text-align: center; margin-bottom: 32px;">
              <span class="trust-bar-title" style="font-size: 0.95rem; font-weight: 700; color: var(--text-main); letter-spacing: 0.02em;">
                Trusted by forward-thinking teams
              </span>
            </div>

            <div class="trust-badges-row">
              <div class="trust-badge-card">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2">
                  <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
                </svg>
                <span>Build Faster</span>
              </div>

              <div class="trust-badge-card">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                </svg>
                <span>Scale Securely</span>
              </div>

              <div class="trust-badge-card">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2">
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                  <polyline points="22 4 12 14.01 9 11.01"/>
                </svg>
                <span>Stay Compliant</span>
              </div>

              <div class="trust-badge-card">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="2" y1="12" x2="22" y2="12"/>
                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
                </svg>
                <span>Unlock Possibilities</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      ${renderFooter()}
    </div>
  `;
}
